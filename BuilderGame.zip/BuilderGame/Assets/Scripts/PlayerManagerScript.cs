﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerManagerScript : MonoBehaviour {
    [SerializeField] private GameObject[] workers;
    [SerializeField] GameObject buildObject;
    private GameObject[] players;
    private bool[] isPlayerBuilding;

    Vector2 targetPos, tempPos;
    float speed = 90;

    GlobalVariables globalVars;
    private Queue<Vector2> targetPositions = new Queue<Vector2>();
    private bool finished = true;
    int index = 0;


    // Use this for initialization
    void Start () {
        globalVars = GameObject.Find("BuildObject").GetComponent<PlacementScript>().globalVars;
        players = new GameObject[workers.Length];
        isPlayerBuilding = new bool[workers.Length];

        targetPos = transform.position;
        for (int i = 0; i < workers.Length; i++)
        {
            players[i] = Instantiate(workers[i], new Vector2(( (i+1) * 30), -130), Quaternion.identity);
            isPlayerBuilding[i] = true;
        }
    }

    IEnumerator FinishBuilding(GameObject buildObject, int isPlayerBuildingIndex)
    {


        yield return new WaitForSeconds(3);
        Debug.Log(buildObject.GetComponent<SpriteRenderer>().color);
        buildObject.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 1);
        Debug.Log(buildObject.GetComponent<SpriteRenderer>().color);
        isPlayerBuilding[isPlayerBuildingIndex] = true;
        targetPositions.Dequeue();
        print(targetPositions.Count);
    }

    // Update is called once per frame
    void Update () {
        if (Input.GetMouseButtonDown(0))
        {


            //position of the buildobject sprite
            targetPos = (Vector2)Camera.main.ScreenToWorldPoint(Input.mousePosition);
            targetPositions.Enqueue(targetPos);

        }
        if (targetPositions.Count > 0 && finished)
        {
           
            int buildObjectCount = buildObject.GetComponent<PlacementScript>().globalVars.buildObjects.Count;
            for (int i = 0; i < targetPositions.Count; i++)
                {
                   
                    if (isPlayerBuilding[i])
                    {
                        tempPos = targetPositions.Peek();
                        players[i].GetComponent<Transform>().position = Vector2.MoveTowards(players[0].GetComponent<Transform>().position, tempPos, speed * Time.deltaTime);
                    }  
                    if ((Vector2)players[i].GetComponent<Transform>().position == tempPos)
                    {
                        index = i;
                        isPlayerBuilding[index] = false;
                        if (buildObject.GetComponent<PlacementScript>().globalVars.buildObjects.Count > 0)
                        {
                            GameObject tempObject = buildObject.GetComponent<PlacementScript>().globalVars.buildObjects.Dequeue();

                            StartCoroutine(FinishBuilding(tempObject, index));
                        }
                        break;
                    }
                }
              

            



        }
    }
}
