﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class ObjectScript : MonoBehaviour {
    [SerializeField] private GameObject finalObject;
    
    
    private Vector2 mousePos ;
    private Vector3 temp;
    private float objectAlpha = 0.5f;
    public GlobalVariables globalVars;
    public int objectCount = 0;
    GameObject buildObject;
 





    [SerializeField] private LayerMask allTilesLayer;
	// Use this for initialization
	void Start () {
        globalVars = new GlobalVariables();
 

    }

    



    // Update is called once per frame
    void Update () {


        //get mouse position in the world
        mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        //round coordinates to get that grid effect
        transform.position = new Vector2(Mathf.Round(mousePos.x), Mathf.Round(mousePos.y));

        
        
        if (Input.GetMouseButtonDown(0)){
            Debug.Log("object script add");
            //Vector2 mouseRay = Camera.main.ScreenToWorldPoint(transform.position);
            RaycastHit2D rayHit = Physics2D.Raycast(mousePos, Vector2.zero, Mathf.Infinity, allTilesLayer);
            

            if(rayHit.collider == null) {//if there is no existing object

            
                objectCount++;
                buildObject = Instantiate(finalObject, transform.position, Quaternion.identity);
                buildObject.name = "object_" + objectCount;
                buildObject.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, objectAlpha);
                globalVars.buildObjects.Enqueue(buildObject);
            }

        }

    }
}
