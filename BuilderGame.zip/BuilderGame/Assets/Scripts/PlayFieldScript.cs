﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayFieldScript : MonoBehaviour {

    public Transform tilePrefab;
    private Vector2 mapSize = new Vector2(50,50);


    private float outlinePercent = 0f;

	// Use this for initialization
	void Start () {
        GenerateMap();
	}


    public void GenerateMap()
    {
        for (int x=0;x<mapSize.x; x++)
        {
            for(int y = 0; y < mapSize.y; y++)
            {
 
                Vector2 tilePosition = new Vector2((-mapSize.x / 2 + 0.5f + 6*x)-125, (-mapSize.y / 2 + 0.5f + 6*y)-125  );
               
                Transform newTile = Instantiate(tilePrefab, tilePosition, Quaternion.identity) as Transform;
                newTile.localScale = Vector2.one * (1 - outlinePercent);
            }
        }
    }
	
	
}
