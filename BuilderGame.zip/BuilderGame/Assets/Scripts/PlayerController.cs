﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerController : MonoBehaviour {

    //[SerializeField] Transform target;
    [SerializeField] GameObject buildObject;


    Vector2 targetPos, temp;
    float speed = 90;

    GlobalVariables globalVars;
    private Queue<Vector2> targetPositions = new Queue<Vector2>();
    private bool finished = true;






    private void Start()
    {
        //this gets the same globalVars manipulated in PlacementScript that's attached to BuildObject
        globalVars = GameObject.Find("BuildObject").GetComponent<PlacementScript>().globalVars;
        //Debug.Log(globalVars.buildObjects.Count);
        //

        //Debug.Log(GameObject.Find("ChalkboardTemplate"));
        //this gets the same globalVars manipulated in PlacementScript that's attached to ChalkboardTemplate
        //globalVars = GameObject.Find("ChalkboardTemplate").GetComponent<ObjectScript>().globalVars;
        targetPos = transform.position;
      

    }

    IEnumerator FinishBuilding(GameObject buildObject)
    {
        
        yield return new WaitForSeconds(3);
        Debug.Log(buildObject.GetComponent<SpriteRenderer>().color);
        buildObject.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, 1);
        Debug.Log(buildObject.GetComponent<SpriteRenderer>().color);
        finished = true;
        targetPositions.Dequeue();
        print(targetPositions.Count);
    }



    // Update is called once per frame
    void Update()
    {
        if (Input.GetMouseButtonDown(0))
        {
            targetPos = (Vector2)Camera.main.ScreenToWorldPoint(Input.mousePosition);
            //target.position = targetPos;
            targetPositions.Enqueue(targetPos);
            


        }
        if (targetPositions.Count > 0 && finished)
        {
            //Debug.Log(targetPositions.Count);
            if (finished)
            {
                temp = targetPositions.Peek();
                
                transform.position = Vector2.MoveTowards(transform.position, temp, speed * Time.deltaTime);
            }
            if ((Vector2)transform.position == temp)
            {
               
                
                finished = false;

                //GameObject temp = globalVars.buildObjects.Dequeue();

                //GameObject buildObject = GameObject.Find(temp.name);

                GameObject temp = buildObject.GetComponent<PlacementScript>().globalVars.buildObjects.Dequeue();
               
                StartCoroutine(FinishBuilding(temp));





            }



        }

    



    }
}
