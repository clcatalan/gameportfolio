﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GlobalVariables  {

    public Queue <GameObject> buildObjects =  new Queue <GameObject>();
}
