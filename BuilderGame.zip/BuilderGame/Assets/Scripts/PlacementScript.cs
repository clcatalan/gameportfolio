﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlacementScript : MonoBehaviour {
    private int selectedObjectInArray;
    private GameObject currentlySelectedObject, buildObject;

    [SerializeField] private GameObject[] selectableObjects;
    [SerializeField] private GameObject[] finalObjects;
    private bool isAnObjectSelected = false;
    private float objectAlpha = 0.5f;
    public GlobalVariables globalVars;
    public int objectCount = 0;

    [SerializeField] private LayerMask allTilesLayer;
    // Use this for initialization
    void Start () {
        globalVars = new GlobalVariables();
        selectedObjectInArray = 0;
	}
	
	// Update is called once per frame
	void Update () {
        Vector2 mousePos = Camera.main.ScreenToWorldPoint(Input.mousePosition);
        
        Vector2 spawnPos = new Vector2(Mathf.Round(mousePos.x), Mathf.Round(mousePos.y));
        //Debug.Log(spawnPos);
        if (Input.GetKeyDown("e") && isAnObjectSelected == false) //press 'e' to generate sprite
        {
           
            currentlySelectedObject = (GameObject)Instantiate(selectableObjects[selectedObjectInArray], spawnPos, Quaternion.identity);
            isAnObjectSelected = true;
        }

        if(Input.GetMouseButtonDown(1) && isAnObjectSelected)
        {
            Destroy(currentlySelectedObject);
            isAnObjectSelected = false;
            selectedObjectInArray = 0;
        }

        if(Input.GetAxis("Mouse ScrollWheel")> 0 && isAnObjectSelected == true) //scroll up
        {
            selectedObjectInArray++;

            if (selectedObjectInArray > selectableObjects.Length - 1)
            {
                selectedObjectInArray = 0;
            }

            Destroy(currentlySelectedObject);
            currentlySelectedObject = (GameObject)Instantiate(selectableObjects[selectedObjectInArray], spawnPos, Quaternion.identity);

        }

        else if(Input.GetAxis("Mouse ScrollWheel") < 0 && isAnObjectSelected == true) //scroll down
        {
            selectedObjectInArray--;

            if (selectedObjectInArray < 0)
            {
                selectedObjectInArray = selectableObjects.Length - 1;
            }

            Destroy(currentlySelectedObject);
            currentlySelectedObject = (GameObject)Instantiate(selectableObjects[selectedObjectInArray], spawnPos, Quaternion.identity);

        }

        if (currentlySelectedObject) //sprite follows mouse
        {
            currentlySelectedObject.GetComponent<Transform>().position = spawnPos;
        }
        
        
        if (Input.GetMouseButtonDown(0)) //left click to place object on field
        {


            RaycastHit2D rayHit = Physics2D.Raycast(mousePos, Vector2.zero, Mathf.Infinity, allTilesLayer);


            if (rayHit.collider == null)
            {//if there is no existing object
                objectCount++;
                buildObject = Instantiate(finalObjects[selectedObjectInArray], spawnPos, Quaternion.identity);
                buildObject.name = "object_" + objectCount;
                buildObject.GetComponent<SpriteRenderer>().color = new Color(1, 1, 1, objectAlpha);
                globalVars.buildObjects.Enqueue(buildObject);
    
            }

        }
    }
}
